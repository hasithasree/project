# Datasets
This repo contains the datasets that are required during different training programs


**What is Dataset and Where to find Dataset** - [Click Here to Know](https://github.com/AP-State-Skill-Development-Corporation/Datasets/wiki)
